module.exports = 'test_file_stub';
