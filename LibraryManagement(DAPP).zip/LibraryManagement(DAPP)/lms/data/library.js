const library = {
  accounts: [],
  account: '',
  ownerDetails: {
    name: '',
    ownAccount: '',
    status: '',
    timestamp: ''
  }
}

export default library
